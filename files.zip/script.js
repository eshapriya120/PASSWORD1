function setMet(id, val) {
  const el = document.getElementById(id);
  val ? el.classList.add('met') : el.classList.remove('met');
}

function analyze() {
  const pw = document.getElementById('pwInput').value;
  const len = pw.length;
  const nums = (pw.match(/\d/g) || []);
  const specials = (pw.match(/[^a-zA-Z0-9]/g) || []);
  const hasLetter = /[a-zA-Z]/.test(pw);
  const hasLower = /[a-z]/.test(pw);
  const hasUpper = /[A-Z]/.test(pw);

  /* Weak criteria — removed: 6-7 chars & no special chars */
  setMet('c-nums',     nums.length >= 1);
  setMet('c-letters',  hasLetter);

  /* Medium criteria */
  setMet('c-len1015',  len >= 10 && len <= 15);
  setMet('c-lower',    hasLower);
  setMet('c-special1', specials.length >= 1);
  setMet('c-num2',     nums.length >= 2);

  /* Strong criteria */
  setMet('c-len1016',  len >= 10 && len <= 16);
  setMet('c-upper',    hasUpper);
  setMet('c-special2', specials.length >= 2);
  setMet('c-num4',     nums.length >= 4);

  const fill  = document.getElementById('strengthFill');
  const label = document.getElementById('strengthLabel');

  if (!pw) {
    fill.style.width = '0%';
    fill.style.background = '#333';
    label.textContent = 'No password entered';
    label.style.color = '#555';
    return;
  }

  const isStrong = len >= 10 && len <= 16 && hasUpper && hasLower && specials.length >= 2 && nums.length >= 4;
  const isMedium = len >= 10 && len <= 15 && hasLower && specials.length >= 1 && nums.length >= 2;
  const isWeak   = nums.length >= 1 && hasLetter;

  if (isStrong) {
    fill.style.width = '100%'; fill.style.background = '#52c41a';
    label.textContent = '🔒 Strong password — excellent!';
    label.style.color = '#52c41a';
  } else if (isMedium) {
    fill.style.width = '60%'; fill.style.background = '#ffa940';
    label.textContent = '🔶 Medium strength — add more complexity';
    label.style.color = '#ffa940';
  } else if (isWeak) {
    fill.style.width = '25%'; fill.style.background = '#ff4d4f';
    label.textContent = '🛡️ Weak password — not recommended';
    label.style.color = '#ff4d4f';
  } else {
    const score = Math.min(85, Math.max(5,
      len * 5 + (hasUpper ? 8 : 0) + (hasLower ? 5 : 0) +
      specials.length * 10 + nums.length * 5
    ));
    fill.style.width = score + '%';
    fill.style.background = score > 55 ? '#ffa940' : '#ff4d4f';
    label.textContent = len < 1 ? 'Start typing a password' : 'Keep going — check criteria below';
    label.style.color = '#888';
  }
}

function toggleVis() {
  const inp  = document.getElementById('pwInput');
  const icon = document.getElementById('eyeIcon');
  inp.type = inp.type === 'password' ? 'text' : 'password';
  icon.className = inp.type === 'password' ? 'fa fa-eye' : 'fa fa-eye-slash';
}

const SPECIALS = '!@#$%^&*';
const LOWER    = 'abcdefghijklmnopqrstuvwxyz';
const UPPER    = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const DIGITS   = '0123456789';

function rand(s) { return s[Math.floor(Math.random() * s.length)]; }

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function generate(level) {
  let chars = [];
  if (level === 'weak') {
    chars.push(rand(UPPER), rand(DIGITS));
    while (chars.length < 6 + Math.floor(Math.random() * 2))
      chars.push(rand(LOWER + DIGITS));
  } else if (level === 'medium') {
    chars.push(rand(LOWER), rand(SPECIALS), rand(DIGITS), rand(DIGITS));
    while (chars.length < 10 + Math.floor(Math.random() * 5))
      chars.push(rand(LOWER + DIGITS));
  } else {
    chars.push(rand(UPPER), rand(SPECIALS), rand(SPECIALS));
    for (let i = 0; i < 4; i++) chars.push(rand(DIGITS));
    while (chars.length < 12 + Math.floor(Math.random() * 4))
      chars.push(rand(LOWER));
  }
  const pw = shuffle(chars).join('');
  const inp = document.getElementById('pwInput');
  inp.value = pw;
  analyze();
  navigator.clipboard.writeText(pw).then(showToast).catch(() => {});
}

function showToast() {
  const t = document.getElementById('toast');
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}
